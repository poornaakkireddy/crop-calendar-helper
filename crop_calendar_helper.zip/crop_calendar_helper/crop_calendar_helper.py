#!/usr/bin/env python3
"""Crop Calendar Helper - store crop tasks by month and show a sowing/care calendar.

Standard library only (Python 3.10+). Run:  python crop_calendar_helper.py
Data is saved to crop_tasks.json next to this script.
"""
from __future__ import annotations

import csv
import json
import os
import shutil
from collections import Counter
from dataclasses import dataclass, asdict
from datetime import date, datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "crop_tasks.json")
EXPORT_DIR = os.path.join(BASE_DIR, "exports")
SAMPLE_JSON = os.path.join(BASE_DIR, "sample_tasks.json")
SAMPLE_CSV = os.path.join(BASE_DIR, "sample_tasks.csv")
IMPORT_LOG = os.path.join(BASE_DIR, "import_errors.log")

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
TASK_TYPES = ["Sowing", "Care", "Irrigation", "Fertilizing",
              "Weeding", "Pest Control", "Harvest"]
STATUSES = ["Pending", "Done"]
MAX_CROP, MAX_NOTES = 40, 200
PAGE_SIZE = 10

# ANSI colours (harmless if unsupported on very old terminals)
GREEN, YELLOW, RED, CYAN, BOLD, RESET = (
    "\033[92m", "\033[93m", "\033[91m", "\033[96m", "\033[1m", "\033[0m")


# ----------------------------------------------------------------- model
@dataclass
class Task:
    id: int
    crop: str
    task_type: str
    month: int          # 1-12
    status: str = "Pending"
    notes: str = ""


def validate_fields(crop, task_type, month, status, notes) -> tuple[dict | None, str]:
    """Return (clean_dict, '') if valid else (None, error message)."""
    crop = str(crop).strip()
    if not crop:
        return None, "crop name is blank"
    if len(crop) > MAX_CROP:
        return None, f"crop name longer than {MAX_CROP} characters"
    if not all(ch.isalnum() or ch in " -'." for ch in crop):
        return None, "crop name has invalid characters"
    tt = next((t for t in TASK_TYPES if t.lower() == str(task_type).strip().lower()), None)
    if tt is None:
        return None, f"task type must be one of {', '.join(TASK_TYPES)}"
    m = parse_month(str(month))
    if m is None:
        return None, "month must be 1-12 or a month name"
    st = next((s for s in STATUSES if s.lower() == str(status).strip().lower()), None)
    if st is None:
        return None, f"status must be one of {', '.join(STATUSES)}"
    notes = str(notes).strip()
    if len(notes) > MAX_NOTES:
        return None, f"notes longer than {MAX_NOTES} characters"
    return {"crop": crop.title(), "task_type": tt, "month": m,
            "status": st, "notes": notes}, ""


def parse_month(text: str) -> int | None:
    text = text.strip().lower()
    if text.isdigit() and 1 <= int(text) <= 12:
        return int(text)
    for i, name in enumerate(MONTHS, 1):
        if text[:3] == name.lower() and len(text) >= 3:
            return i
    return None


# ------------------------------------------------------------ persistence
def load_tasks() -> list[Task]:
    """Load tasks; survive missing, corrupt or partially invalid files."""
    try:
        with open(DATA_FILE, encoding="utf-8") as f:
            raw = json.load(f)
        if not isinstance(raw, list):
            raise json.JSONDecodeError("expected a list", "", 0)
    except FileNotFoundError:
        save_tasks([])
        return []
    except (json.JSONDecodeError, UnicodeDecodeError):
        backup = DATA_FILE + ".corrupt"
        shutil.copy(DATA_FILE, backup)
        print(f"{YELLOW}Data file was corrupted. Backed up to {backup}; starting fresh.{RESET}")
        save_tasks([])
        return []
    tasks, skipped = [], 0
    for item in raw:
        try:
            clean, err = validate_fields(item["crop"], item["task_type"], item["month"],
                                         item.get("status", "Pending"), item.get("notes", ""))
            if err:
                raise ValueError(err)
            tasks.append(Task(id=int(item["id"]), **clean))
        except (KeyError, TypeError, ValueError):
            skipped += 1
    if skipped:
        print(f"{YELLOW}Skipped {skipped} invalid record(s) in data file.{RESET}")
    return tasks


def save_tasks(tasks: list[Task]) -> None:
    """Atomic write so a crash mid-save cannot corrupt the file."""
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump([asdict(t) for t in tasks], f, indent=2)
    os.replace(tmp, DATA_FILE)


def next_id(tasks: list[Task]) -> int:
    return max((t.id for t in tasks), default=0) + 1


# ------------------------------------------------------------ input helpers
def ask_text(prompt: str, max_len: int, allow_blank: bool = False) -> str:
    while True:
        val = input(prompt).strip()
        if not val and not allow_blank:
            print(f"{RED}  Cannot be blank.{RESET}")
        elif len(val) > max_len:
            print(f"{RED}  Max {max_len} characters (you typed {len(val)}).{RESET}")
        else:
            return val


def ask_month(prompt: str = "Month (1-12 or name): ") -> int:
    while True:
        m = parse_month(input(prompt))
        if m:
            return m
        print(f"{RED}  Enter a number 1-12 or a month name like 'Mar'.{RESET}")


def ask_choice(prompt: str, options: list[str]) -> str:
    for i, o in enumerate(options, 1):
        print(f"  {i}. {o}")
    while True:
        raw = input(prompt).strip()
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1]
        match = [o for o in options if o.lower() == raw.lower()]
        if match:
            return match[0]
        print(f"{RED}  Pick a number 1-{len(options)}.{RESET}")


def ask_int(prompt: str) -> int:
    while True:
        raw = input(prompt).strip()
        if raw.isdigit():
            return int(raw)
        print(f"{RED}  Please enter a whole number.{RESET}")


# ---------------------------------------------------------------- display
def fmt_row(t: Task) -> str:
    colour = GREEN if t.status == "Done" else (RED if is_overdue(t) else YELLOW)
    return (f"{t.id:>4} | {t.crop:<18.18} | {t.task_type:<12} | {MONTHS[t.month-1]:<3} | "
            f"{colour}{t.status:<7}{RESET} | {t.notes[:30]}")


HEADER = f"{'ID':>4} | {'Crop':<18} | {'Task':<12} | Mon | {'Status':<7} | Notes\n" + "-" * 80


def show_table(tasks: list[Task]) -> None:
    if not tasks:
        print("  (no matching records)")
        return
    tasks = sorted(tasks, key=lambda t: (t.month, t.crop, t.id))
    for start in range(0, len(tasks), PAGE_SIZE):
        print(HEADER)
        for t in tasks[start:start + PAGE_SIZE]:
            print(fmt_row(t))
        end = start + PAGE_SIZE
        if end < len(tasks):
            if input(f"-- {min(end, len(tasks))}/{len(tasks)} shown. Enter = next page, q = stop: ").lower() == "q":
                break
    print(f"Total: {len(tasks)} record(s)")


def is_overdue(t: Task) -> bool:
    """Pending task whose month already passed this year."""
    return t.status == "Pending" and t.month < date.today().month


def show_calendar(tasks: list[Task]) -> None:
    print(f"\n{BOLD}{CYAN}=== Crop Calendar ==={RESET}")
    for m in range(1, 13):
        items = [t for t in tasks if t.month == m]
        marker = " <- current month" if m == date.today().month else ""
        print(f"\n{BOLD}{MONTHS[m-1]}{RESET}{marker}")
        if not items:
            print("   -")
        for t in sorted(items, key=lambda x: (x.task_type != "Sowing", x.crop)):
            tick = f"{GREEN}[x]{RESET}" if t.status == "Done" else (
                f"{RED}[!]{RESET}" if is_overdue(t) else "[ ]")
            print(f"   {tick} {t.task_type:<12} {t.crop}")


# ---------------------------------------------------------------- features
def add_task(tasks: list[Task]) -> None:
    print(f"\n{BOLD}Add a crop task{RESET}")
    crop = ask_text("Crop name: ", MAX_CROP)
    task_type = ask_choice("Task type: ", TASK_TYPES)
    month = ask_month()
    notes = ask_text("Notes (optional): ", MAX_NOTES, allow_blank=True)
    clean, err = validate_fields(crop, task_type, month, "Pending", notes)
    if err:
        print(f"{RED}Not saved: {err}{RESET}")
        return
    if any(t.crop == clean["crop"] and t.task_type == clean["task_type"]
           and t.month == clean["month"] for t in tasks):
        print(f"{YELLOW}Warning: identical task already exists - added anyway.{RESET}")
    tasks.append(Task(id=next_id(tasks), **clean))
    save_tasks(tasks)
    print(f"{GREEN}Saved.{RESET}")


def search_tasks(tasks: list[Task]) -> None:
    print("\nSearch by: 1) keyword  2) month  3) task type  4) status")
    mode = ask_int("Choice: ")
    if mode == 1:
        kw = ask_text("Keyword (crop or notes): ", 40).lower()
        res = [t for t in tasks if kw in t.crop.lower() or kw in t.notes.lower()]
    elif mode == 2:
        m = ask_month()
        res = [t for t in tasks if t.month == m]
    elif mode == 3:
        tt = ask_choice("Task type: ", TASK_TYPES)
        res = [t for t in tasks if t.task_type == tt]
    elif mode == 4:
        st = ask_choice("Status: ", STATUSES)
        res = [t for t in tasks if t.status == st]
    else:
        print(f"{RED}Unknown option.{RESET}")
        return
    show_table(res)


def mark_done(tasks: list[Task]) -> None:
    tid = ask_int("Task ID to mark done: ")
    for t in tasks:
        if t.id == tid:
            t.status = "Done"
            save_tasks(tasks)
            print(f"{GREEN}Marked '{t.crop} - {t.task_type}' as Done.{RESET}")
            return
    print(f"{RED}No task with ID {tid}.{RESET}")


def delete_task(tasks: list[Task]) -> None:
    tid = ask_int("Task ID to delete: ")
    for t in tasks:
        if t.id == tid:
            if input(f"Delete '{t.crop} - {t.task_type}'? (y/N): ").lower() == "y":
                tasks.remove(t)
                save_tasks(tasks)
                print("Deleted.")
            return
    print(f"{RED}No task with ID {tid}.{RESET}")


def compute_summary(tasks: list[Task]) -> dict:
    total = len(tasks)
    done = sum(t.status == "Done" for t in tasks)
    by_month = Counter(t.month for t in tasks)
    active = len(by_month)
    return {
        "total": total,
        "done": done,
        "pending": total - done,
        "completion_pct": round(100 * done / total, 1) if total else 0.0,
        "overdue": sum(is_overdue(t) for t in tasks),
        "crops": len({t.crop for t in tasks}),
        "by_type": Counter(t.task_type for t in tasks),
        "by_month": by_month,
        "avg_per_active_month": round(total / active, 1) if active else 0.0,
        "busiest": by_month.most_common(1)[0] if by_month else None,
    }


def summary_lines(tasks: list[Task]) -> list[str]:
    s = compute_summary(tasks)
    lines = [
        "Crop Calendar Summary",
        f"Generated: {datetime.now():%Y-%m-%d %H:%M}",
        "",
        f"Total tasks:            {s['total']}",
        f"Distinct crops:         {s['crops']}",
        f"Done / Pending:         {s['done']} / {s['pending']}  ({s['completion_pct']}% complete)",
        f"Overdue (pending, past month): {s['overdue']}",
        f"Avg tasks per active month:    {s['avg_per_active_month']}",
    ]
    if s["busiest"]:
        lines.append(f"Busiest month:          {MONTHS[s['busiest'][0]-1]} ({s['busiest'][1]} tasks)")
    lines += ["", "Tasks by type:"]
    lines += [f"  {k:<13}{v:>3}  {'#' * v}" for k, v in s["by_type"].most_common()]
    lines += ["", "Tasks by month:"]
    lines += [f"  {MONTHS[m-1]:<4}{s['by_month'].get(m, 0):>3}  {'#' * s['by_month'].get(m, 0)}"
              for m in range(1, 13)]
    return lines


def show_summary(tasks: list[Task]) -> None:
    print(f"\n{BOLD}{CYAN}" + "\n".join(summary_lines(tasks)) + RESET)
    overdue = [t for t in tasks if is_overdue(t)]
    if overdue:
        print(f"\n{RED}WARNING: {len(overdue)} overdue task(s):{RESET}")
        for t in sorted(overdue, key=lambda x: x.month)[:10]:
            print(f"  {RED}! {MONTHS[t.month-1]}: {t.crop} - {t.task_type}{RESET}")
    this_month = [t for t in tasks if t.month == date.today().month and t.status == "Pending"]
    if this_month:
        print(f"\n{YELLOW}Due this month: {len(this_month)} task(s){RESET}")


def export_reports(tasks: list[Task]) -> None:
    os.makedirs(EXPORT_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # CSV
    csv_path = os.path.join(EXPORT_DIR, f"tasks_{stamp}.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "crop", "task_type", "month", "status", "notes"])
        for t in sorted(tasks, key=lambda x: (x.month, x.crop)):
            w.writerow([t.id, t.crop, t.task_type, t.month, t.status, t.notes])
    # Plain text
    txt_path = os.path.join(EXPORT_DIR, f"summary_{stamp}.txt")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(summary_lines(tasks)) + "\n")
    # Markdown calendar
    md_path = os.path.join(EXPORT_DIR, f"calendar_{stamp}.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Crop Calendar\n\n```\n" + "\n".join(summary_lines(tasks)) + "\n```\n\n")
        f.write("| Month | Task | Crop | Status |\n|---|---|---|---|\n")
        for t in sorted(tasks, key=lambda x: (x.month, x.crop)):
            f.write(f"| {MONTHS[t.month-1]} | {t.task_type} | {t.crop} | {t.status} |\n")
    print(f"{GREEN}Exported:{RESET}\n  {csv_path}\n  {txt_path}\n  {md_path}")


def import_csv(tasks: list[Task]) -> None:
    path = input("Path to CSV (columns: crop,task_type,month,status,notes): ").strip().strip('"')
    try:
        f = open(path, newline="", encoding="utf-8-sig")
    except OSError as e:
        print(f"{RED}Cannot open file: {e}{RESET}")
        return
    ok, errors = 0, []
    with f:
        reader = csv.DictReader(f)
        needed = {"crop", "task_type", "month"}
        if not reader.fieldnames or not needed <= {h.strip().lower() for h in reader.fieldnames}:
            print(f"{RED}CSV must have at least columns: crop, task_type, month.{RESET}")
            return
        for line_no, row in enumerate(reader, start=2):
            row = {(k or "").strip().lower(): (v or "") for k, v in row.items()}
            clean, err = validate_fields(row.get("crop", ""), row.get("task_type", ""),
                                         row.get("month", ""), row.get("status") or "Pending",
                                         row.get("notes", ""))
            if err:
                errors.append(f"line {line_no}: {err} -> {row}")
            else:
                tasks.append(Task(id=next_id(tasks), **clean))
                ok += 1
    save_tasks(tasks)
    if errors:
        with open(IMPORT_LOG, "w", encoding="utf-8") as lf:
            lf.write("\n".join(errors) + "\n")
    print(f"{GREEN}Imported {ok} row(s).{RESET} "
          f"{RED if errors else ''}{len(errors)} rejected"
          f"{' (see ' + IMPORT_LOG + ')' if errors else ''}.{RESET}")


# ---------------------------------------------------------------- sample data
SAMPLE_CROPS = {  # crop: (sow month, harvest month)
    "Wheat": (11, 4), "Rice": (6, 10), "Maize": (6, 9), "Tomato": (2, 6),
    "Potato": (10, 2), "Onion": (11, 4), "Cotton": (5, 11), "Chickpea": (10, 2),
    "Mustard": (10, 2), "Sugarcane": (2, 12),
}


def build_sample() -> list[dict]:
    rows = []
    for crop, (sow, harvest) in SAMPLE_CROPS.items():
        rows.append(dict(crop=crop, task_type="Sowing", month=sow, status="Done",
                         notes="Prepare bed, certified seed"))
        mid = (sow % 12) + 1
        rows.append(dict(crop=crop, task_type="Irrigation", month=mid, status="Pending",
                         notes="Light irrigation after germination"))
        rows.append(dict(crop=crop, task_type="Fertilizing", month=((sow + 1) % 12) + 1,
                         status="Pending", notes="Split-dose nitrogen"))
        rows.append(dict(crop=crop, task_type="Harvest", month=harvest, status="Pending",
                         notes=""))
    # edge cases / boundary values
    rows.append(dict(crop="Garlic", task_type="Weeding", month=1, status="Pending", notes="Boundary: January"))
    rows.append(dict(crop="Spinach", task_type="Pest Control", month=12, status="Pending",
                     notes="x" * MAX_NOTES))
    rows.append(dict(crop="Okra", task_type="Care", month=7, status="Done", notes="Duplicate-style entry"))
    rows.append(dict(crop="Okra", task_type="Care", month=7, status="Done", notes="Duplicate-style entry"))
    return rows[:45]


def write_sample_files() -> None:
    rows = build_sample()
    with open(SAMPLE_JSON, "w", encoding="utf-8") as f:
        json.dump([{"id": i, **r} for i, r in enumerate(rows, 1)], f, indent=2)
    with open(SAMPLE_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["crop", "task_type", "month", "status", "notes"])
        w.writeheader()
        w.writerows(rows)
        # deliberately bad rows to demo the import error log
        w.writerow({"crop": "", "task_type": "Sowing", "month": 3, "status": "Pending", "notes": ""})
        w.writerow({"crop": "Bean", "task_type": "Dancing", "month": 3, "status": "Pending", "notes": ""})
        w.writerow({"crop": "Pea", "task_type": "Sowing", "month": 13, "status": "Pending", "notes": ""})
    print(f"{GREEN}Wrote {SAMPLE_JSON} and {SAMPLE_CSV} ({len(rows)} valid + 3 bad rows in CSV).{RESET}")


def load_sample(tasks: list[Task]) -> None:
    if not os.path.exists(SAMPLE_JSON):
        write_sample_files()
    if tasks and input("This adds sample data to existing tasks. Continue? (y/N): ").lower() != "y":
        return
    for r in build_sample():
        clean, err = validate_fields(r["crop"], r["task_type"], r["month"], r["status"], r["notes"])
        if not err:
            tasks.append(Task(id=next_id(tasks), **clean))
    save_tasks(tasks)
    print(f"{GREEN}Sample data loaded. Total tasks: {len(tasks)}{RESET}")


# ---------------------------------------------------------------- main loop
MENU = """
{b}{c}==============================
   CROP CALENDAR HELPER
=============================={r}
 1. Add crop task
 2. View all tasks
 3. Show calendar
 4. Search / filter
 5. Mark task done
 6. Delete task
 7. Summary & warnings
 8. Export reports
 9. Import CSV
10. Load sample data / write sample files
 0. Exit
""".format(b=BOLD, c=CYAN, r=RESET)


def main() -> None:
    tasks = load_tasks()
    actions = {
        "1": add_task, "2": lambda t: show_table(t), "3": show_calendar,
        "4": search_tasks, "5": mark_done, "6": delete_task, "7": show_summary,
        "8": export_reports, "9": import_csv, "10": load_sample,
    }
    print(f"Loaded {len(tasks)} task(s) from {DATA_FILE}")
    while True:
        print(MENU)
        choice = input("Select an option: ").strip()
        if choice == "0":
            print("Goodbye - your data is saved.")
            return
        action = actions.get(choice)
        if action is None:
            print(f"{RED}Invalid option.{RESET}")
            continue
        try:
            action(tasks)
        except (KeyboardInterrupt, EOFError):
            print("\nCancelled.")
        except OSError as e:
            print(f"{RED}File error: {e}{RESET}")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nGoodbye.")
