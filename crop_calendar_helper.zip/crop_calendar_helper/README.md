# Crop Calendar Helper

Python for Good - Project #66 (Food & Agriculture).
Store crop tasks by month and view a sowing/care calendar. Standard library only, Python 3.10+.

## Run (terminal app)
    python crop_calendar_helper.py

Menu: add task, view all, calendar, search, mark done, delete, summary and warnings,
export reports, import CSV, load sample data.

## View in a web browser
    python web_view.py
Then open http://localhost:8000 (refresh the page after changing data).

## Files
- crop_calendar_helper.py - main terminal app
- web_view.py - read-only browser view of the same data
- sample_tasks.json / sample_tasks.csv - 44 sample tasks (the CSV also has 3 bad rows to demo import errors)
- crop_tasks.json - created automatically on first run (your saved data)
- exports/ - created when you use Export reports
- import_errors.log - created when a CSV import rejects rows

## Quick demo
1. Menu 10: load sample data
2. Menu 1: add a task with bad inputs (blank name, month 13)
3. Menu 3: calendar, Menu 7: summary and warnings
4. Menu 8: export, then 0 to exit
5. Relaunch and open menu 3 to show data persisted
